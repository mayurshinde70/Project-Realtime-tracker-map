const socket = io();

if (navigator.geolocation) {
    navigator.geolocation.watchPosition((position) => {
        const { latitude, longitude } = position.coords;
        socket.emit('send-location', { latitude, longitude });

    }, (error) => {
        console.log(error);
    }, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
    });
}


const mapElementId = "map";
const initialCoordinates = [0, 0];
const initialZoomLevel = 10;

const map = L.map(mapElementId).setView(initialCoordinates, initialZoomLevel);